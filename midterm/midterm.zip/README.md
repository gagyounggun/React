# 가경건 202330101

ERROR
[eslint] 
src\Midterm.js
  Line 31:24:  '사과' is not defined  no-undef

Search for the keywords to learn more about each error.

전체적으로 잘 모르겠습니다!ㅠㅠ