import Midterm from './Midterm.js';
import './App.css';
// App 컴포넌트
export default function App() {
  return (
    <div>
      <Midterm />
    </div>

  );
}
